# React-Play.Template

Author: klequis

This React project template is a modified of the chapter 7 code from React Speed Code.

To use this template - fork it (DO NOT CLONE)
```
fork
```
