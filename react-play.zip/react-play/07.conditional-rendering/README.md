# React-Play.Conditional-Rendering

Author: klequis

This example project will demonstrate several methods to conditionally render components based on state.

## Simple If Statement
If (flight number) Then
  display gate and departure time
Else
  Ask for flight number

## Element Variables
If (everything complete) Then
  Your information is complete. Press the Print button to print your boarding pass.
Else
  To get you boarding pass, please enter all information

## Preventing Component from Rendering
If (flight delay) Then
  Red notice: Your flight is delayed - bummer!
Else
  Hide the notice
