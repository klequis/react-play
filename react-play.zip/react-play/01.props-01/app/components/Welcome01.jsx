import React from 'react';

const Welcome01 = function welcome(props) {
  return <h1>Hello, {props.name}</h1>;
}
// You must use 'export default' or it will not return anything
export default Welcome01;
